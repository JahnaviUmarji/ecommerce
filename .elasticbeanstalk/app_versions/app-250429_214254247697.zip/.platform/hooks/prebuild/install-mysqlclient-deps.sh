#!/bin/bash
dnf install -y gcc mariadb-devel
