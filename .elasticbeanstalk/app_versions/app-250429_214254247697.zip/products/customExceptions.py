
class ProductOutOfStock(Exception):
    pass